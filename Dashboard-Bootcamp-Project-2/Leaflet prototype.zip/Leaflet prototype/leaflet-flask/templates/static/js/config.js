const APIKEY = "pk.eyJ1Ijoic3llZHN1bGFpbWFuMTciLCJhIjoiY2s5ajhtYWM0MWZ4MDNlcDR4anN1eDFlcSJ9.WECLDLGjukeuW04HbL1PZg";

//should not be added.