from flask import Flask, render_template, redirect, request, send_from_directory
from flask_pymongo import PyMongo
import os


app = Flask(__name__, static_url_path='')

app.config["MONGO_URI"] = "mongodb+srv://dbUser:OxTrot2020@cluster0-lfpvw.azure.mongodb.net/test?retryWrites=true&w=majority"
mongo = PyMongo(app)
 
number = 12
@app.route("/")
def index():
    return render_template("index.html", number=number)

@app.route('/static/js')
def send_js(path):
    return send_from_directory('js', path)


if __name__ == "__main__":
    app.run(debug=True)

